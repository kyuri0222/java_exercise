import java.util.*; 

class Word{
	  private String eng;  
	  private String kor;  
	  public Word(String eng, String kor) {
	    this.eng = eng; 
	    this.kor = kor; 
	  } 
	  public String getEng() {return eng;} 
	  public String getKor() {return kor;}
	  public String toString() {
		return "Word [eng=" + eng + ", kor=" + kor + "]";
	} 
} 

public class WordQuiz { 
	  Scanner scanner = new Scanner(System.in); 
	  public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in); 
	    Word sample[] = new Word[4];
	    Word quizNum;
	    
	    Vector<Word> v = new Vector<Word>(); 
	    v.add(new Word("love", "���")); 
	    v.add(new Word("animal", "����")); 
	    v.add(new Word("baby", "�Ʊ�")); 
	    v.add(new Word("emotion", "����")); 
	    v.add(new Word("honey", "��")); 
	    v.add(new Word("human", "�ΰ�")); 
	    v.add(new Word("snow", "��")); 
	    v.add(new Word("photo", "����")); 
	    v.add(new Word("deal", "�ŷ�")); 
	    v.add(new Word("stock", "�ֽ�")); 
	    v.add(new Word("bear", "��")); 
	    v.add(new Word("error", "����")); 
	    v.add(new Word("doll", "����")); 
	    v.add(new Word("picture", "�׸�")); 
	    v.add(new Word("society", "��ȸ")); 
	    
	    System.out.println("\"��ǰ����\"�� �ܾ� �׽�Ʈ�� �����մϴ�.-1�� �Է��ϸ� �����մϴ�."); 
	    System.out.println("���� 17���� �ܾ ��� �ֽ��ϴ�."); 
	    
	    while(true) {
	    	Collections.shuffle(v);
	    	sample[0] = v.get(0);
	    	sample[1] = v.get(1);
	    	sample[2] = v.get(2);
	    	sample[3] = v.get(3);
	    	
	    	int random = (int)(Math.random()*4);
	    	quizNum = v.get(random);
	    	
	    	System.out.println(quizNum.getEng()+"?");
	    	System.out.printf("(1)%s (2)%s (3)%s (4)%s :>",sample[0].getKor(),sample[1].getKor(),sample[2].getKor(),sample[3].getKor());
	    	int n = Integer.parseInt(scanner.nextLine());
	    	
	    	if(n == -1) {
	    		System.out.println("\"��ǰ����\"�� �����մϴ�..."); 
	    		break;
	    	}
	    	
	    	if(quizNum.getKor().equals(sample[n-1].getKor())) System.out.println("Excellent !!");
	    	else System.out.println("No !!");
	    	} 
	    scanner.close();
	  }
}
	